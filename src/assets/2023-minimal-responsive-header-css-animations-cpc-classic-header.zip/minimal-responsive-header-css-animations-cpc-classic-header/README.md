# Minimal Responsive Header & CSS Animations #cpc-classic-header

A Pen created on CodePen.io. Original URL: [https://codepen.io/rafaelavlucas/pen/QWwXKON](https://codepen.io/rafaelavlucas/pen/QWwXKON).

